document.getElementsByTagName("h1")
[0].style.fontsize ="6vw";
